package com.example.novaloader

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 16)
    private val panel = Color.rgb(25, 25, 32)
    private val red = Color.rgb(235, 55, 65)
    private val prefs by lazy { getSharedPreferences("nova", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var configName = "PUBG Mobile — мой профиль"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        text("NOVA  /  LOADER", 13, red, true)
        text(title, 27, Color.WHITE, true)
        text("Локальная панель управления • v1.1", 13, 0xFF9A9AA5.toInt())
        space(16)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) {
        root.addView(TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 5, 0, 5)
        })
    }

    private fun space(h: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, h)) }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun card(title: String, subtitle: String = "") {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(panel)
        }
        box.addView(TextView(this).apply {
            text = title; textSize = 16f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        if (subtitle.isNotBlank()) box.addView(TextView(this).apply {
            text = subtitle; textSize = 12f; setTextColor(0xFFB7B7C1.toInt())
        })
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 })
    }

    private fun showHome() {
        base("Главная")
        card("Добро пожаловать", "Профили, настройки и конфигурации PUBG Mobile.")
        card("Активный профиль", prefs.getString("profile", "По умолчанию") ?: "По умолчанию")
        button("Профили") { showProfiles() }
        button("Конфиги PUBG Mobile") { showPubgConfigs() }
        button("Настройки") { showSettings() }
        button("Модули") { showModules() }
        button("Авторизация") { showAuth() }
        button("Журнал") { showLogs() }
        button("Проверить обновления") { toast("Установлена актуальная локальная версия 1.1") }
        text("Конфиги используются как пользовательские заметки и профили настроек. Приложение не меняет файлы игры и не внедряется в её процесс.", 12, 0xFF9A9AA5.toInt())
    }

    private fun showProfiles() {
        base("Профили")
        val name = EditText(this).apply {
            hint = "Название профиля"; setSingleLine()
            setTextColor(Color.WHITE); setHintTextColor(0xFF888888.toInt())
        }
        root.addView(name)
        button("Сохранить профиль") {
            val n = name.text.toString().ifBlank { "Мой профиль" }
            prefs.edit().putString("profile", n).apply()
            toast("Профиль «$n» сохранён")
            showProfiles()
        }
        card("Текущий профиль", prefs.getString("profile", "По умолчанию") ?: "По умолчанию")
        button("Назад") { showHome() }
    }

    private fun showPubgConfigs() {
        base("Конфиги PUBG Mobile")
        card("Импорт / экспорт", "Формат JSON. Файл хранится там, куда ты сам его импортируешь или экспортируешь.")
        val name = EditText(this).apply {
            setText(configName); hint = "Название конфига"
            setTextColor(Color.WHITE); setHintTextColor(0xFF888888.toInt())
        }
        root.addView(name)
        val camera = numberField("Камера без прицела", "120")
        val redDot = numberField("Коллиматор / Red Dot", "50")
        val scope3 = numberField("Прицел 3x", "30")
        val scope4 = numberField("Прицел 4x", "25")
        val ads = numberField("Чувствительность ADS", "100")
        val gyro = numberField("Гироскоп", "300")
        val gyroAds = numberField("Гироскоп ADS", "300")
        button("Импортировать JSON") {
            configName = name.text.toString().ifBlank { "Импортированный конфиг" }
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            }
            startActivityForResult(i, 101)
        }
        button("Экспортировать JSON") {
            configName = name.text.toString().ifBlank { "PUBG Mobile — мой профиль" }
            val obj = JSONObject()
                .put("app", "Nova Loader")
                .put("format_version", 1)
                .put("game", "PUBG Mobile")
                .put("name", configName)
                .put("camera_no_scope", camera.text.toString().toIntOrNull() ?: 120)
                .put("red_dot", redDot.text.toString().toIntOrNull() ?: 50)
                .put("scope_3x", scope3.text.toString().toIntOrNull() ?: 30)
                .put("scope_4x", scope4.text.toString().toIntOrNull() ?: 25)
                .put("ads", ads.text.toString().toIntOrNull() ?: 100)
                .put("gyroscope", gyro.text.toString().toIntOrNull() ?: 300)
                .put("gyroscope_ads", gyroAds.text.toString().toIntOrNull() ?: 300)
            prefs.edit().putString("last_config", obj.toString()).apply()
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "nova_pubg_config.json")
            }
            pendingExport = obj.toString(2)
            startActivityForResult(i, 102)
        }
        button("Назад") { showHome() }
    }

    private fun numberField(label: String, defaultValue: String): EditText {
        text(label, 13, 0xFFD0D0D8.toInt())
        return EditText(this).also { field ->
            field.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            field.setText(defaultValue)
            field.setTextColor(Color.WHITE)
            field.setHintTextColor(0xFF888888.toInt())
            root.addView(field)
        }
    }

    private var pendingExport: String = ""

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try {
            when (requestCode) {
                101 -> {
                    val content = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    val obj = JSONObject(content)
                    configName = obj.optString("name", "Импортированный конфиг")
                    prefs.edit().putString("last_config", obj.toString()).putString("config_name", configName).apply()
                    toast("Конфиг «$configName» импортирован")
                    showPubgConfigs()
                }
                102 -> {
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingExport) }
                    toast("JSON-конфиг экспортирован")
                }
            }
        } catch (e: Exception) {
            toast("Ошибка файла: ${e.message ?: "не удалось обработать JSON"}")
        }
    }

    private fun showSettings() {
        base("Настройки")
        listOf("Уведомления", "Автосохранение", "Компактный интерфейс").forEach { key ->
            val sw = Switch(this).apply {
                text = key; textSize = 15f; setTextColor(Color.WHITE)
                isChecked = prefs.getBoolean(key, key == "Автосохранение")
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
            }
            root.addView(sw)
        }
        space(12)
        button("Назад") { showHome() }
    }

    private fun showModules() {
        base("Модули")
        card("Менеджер конфигураций", "Импорт и экспорт JSON-профилей.")
        card("Диагностика", "Локальный журнал и проверка состояния приложения.")
        card("Дополнительные модули", "В этой версии доступны только безопасные локальные расширения интерфейса.")
        text("Изменение памяти игры, внедрение кода и обход античита не поддерживаются.", 12, 0xFFFF9B9B.toInt())
        button("Назад") { showHome() }
    }

    private fun showAuth() {
        base("Авторизация")
        card("Локальный режим", "Демо-авторизация без сетевого сервера и покупки ключей.")
        val key = EditText(this).apply {
            hint = "Введите локальный ключ DEMO-NOVA"
            setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(0xFF888888.toInt())
        }
        root.addView(key)
        button("Войти") {
            if (key.text.toString() == "DEMO-NOVA") {
                prefs.edit().putBoolean("authorized", true).apply()
                toast("Вход выполнен")
            } else toast("Для демо-доступа используй DEMO-NOVA")
        }
        text(if (prefs.getBoolean("authorized", false)) "Статус: авторизован" else "Статус: не авторизован", 13, 0xFFB7B7C1.toInt())
        button("Назад") { showHome() }
    }

    private fun showLogs() {
        base("Журнал")
        val log = TextView(this).apply {
            text = "Nova Loader запущен\nНастройки хранятся локально.\nИмпорт/экспорт конфигов выполняется через системный выбор файлов."
            setTextColor(Color.WHITE); textSize = 14f
            setPadding(12, 12, 12, 12); setBackgroundColor(panel)
        }
        root.addView(log)
        button("Очистить журнал") { log.text = "Журнал очищен" }
        button("Назад") { showHome() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
